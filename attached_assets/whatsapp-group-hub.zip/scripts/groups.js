import { collection, addDoc, getDocs, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";
import { db } from './firebase-config.js';

// Display groups
async function displayGroups() {
    try {
        const querySnapshot = await getDocs(collection(db, "groups"));
        const archiveDiv = document.getElementById("groupArchive");
        archiveDiv.innerHTML = "";

        querySnapshot.forEach((doc) => {
            const data = doc.data();
            if (!data.title || !data.link) return;

            // Check for image in preview or use fallback
            const hasImage = data.image && data.image !== "undefined" && data.image !== "null";
            const imageHtml = hasImage 
                ? `<img src="${data.image}" alt="${data.title}" class="mb-3 group-image" onerror="this.src='https://via.placeholder.com/300x200?text=No+Preview+Available'">`
                : '<div class="no-image-placeholder mb-3">No Preview Available</div>';

            const postHTML = `
                <div class="group-card">
                    ${imageHtml}
                    <h4>${data.title}</h4>
                    <div class="mb-2">
                        <span class="badge bg-secondary">${data.category || "Uncategorized"}</span>
                    </div>
                    <p class="text-muted">${data.description || "No description"}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <a href="${data.link}" target="_blank" class="btn btn-primary btn-sm">
                            <i class="fab fa-whatsapp"></i> Join Group
                        </a>
                        <small class="text-muted">
                            ${data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleDateString() : "N/A"}
                        </small>
                    </div>
                </div>
            `;
            archiveDiv.innerHTML += postHTML;
        });
    } catch (error) {
        console.error("Error loading groups:", error);
        showError("Failed to load groups. Please try again later.");
    }
}

// Submit group
async function submitGroup() {
    try {
        const title = document.getElementById("groupTitle").value.trim();
        const link = document.getElementById("groupLink").value.trim();
        const category = document.getElementById("groupCategory").value.trim();
        const description = document.getElementById("groupDescription").value.trim();

        // Get preview image from the preview container
        const previewImg = document.querySelector("#preview img");
        const imageUrl = previewImg ? previewImg.src : null;

        if (!title || !link || !category || !description) {
            showError("Please fill all required fields");
            return;
        }

        if (!link.includes("chat.whatsapp.com")) {
            showError("Please enter a valid WhatsApp group link");
            return;
        }

        const groupData = {
            title,
            link,
            category,
            description,
            image: imageUrl, // Store the preview image URL
            timestamp: serverTimestamp()
        };

        console.log("Submitting group with image:", imageUrl); // Debug log

        await addDoc(collection(db, "groups"), groupData);
        showSuccess("Group added successfully!");
        clearForm();
        await displayGroups();
    } catch (error) {
        console.error("Error adding group:", error);
        showError("Failed to add group. Please try again.");
    }
}

function clearForm() {
    document.getElementById("groupTitle").value = "";
    document.getElementById("groupLink").value = "";
    document.getElementById("groupCategory").value = "";
    document.getElementById("groupDescription").value = "";
    document.getElementById("preview").innerHTML = "";
}

function showError(message) {
    const alertHTML = `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    document.querySelector(".card-body").insertAdjacentHTML('afterbegin', alertHTML);
}

function showSuccess(message) {
    const alertHTML = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    document.querySelector(".card-body").insertAdjacentHTML('afterbegin', alertHTML);
}

// Initialize
window.onload = displayGroups;
window.submitGroup = submitGroup;