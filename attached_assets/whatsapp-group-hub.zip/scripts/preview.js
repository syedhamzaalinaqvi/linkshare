async function fetchOpenGraph(url) {
    try {
        const response = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(url)}`);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        const parser = new DOMParser();
        const doc = parser.parseFromString(data.contents, "text/html");

        // Extract OpenGraph metadata
        const ogTitle = doc.querySelector('meta[property="og:title"]')?.content || 
                       doc.querySelector('meta[name="title"]')?.content ||
                       doc.title || "No Title Found";
                       
        const ogImage = doc.querySelector('meta[property="og:image"]')?.content || 
                       doc.querySelector('meta[name="image"]')?.content ||
                       "https://via.placeholder.com/150?text=No+Image";
                       
        const ogDescription = doc.querySelector('meta[property="og:description"]')?.content || 
                            doc.querySelector('meta[name="description"]')?.content ||
                            "No Description Available";

        // Create preview
        document.getElementById("preview").innerHTML = `
            <div class="preview-box">
                <div class="d-flex gap-3">
                    <img src="${ogImage}" alt="Preview" class="preview-image">
                    <div>
                        <h5 class="mb-1">${ogTitle}</h5>
                        <p class="small text-muted mb-0">${ogDescription}</p>
                    </div>
                </div>
            </div>
        `;
    } catch (error) {
        console.error("Error fetching preview:", error);
        document.getElementById("preview").innerHTML = `
            <div class="alert alert-warning" role="alert">
                <i class="fas fa-exclamation-triangle"></i> 
                Could not load preview for this link
            </div>
        `;
    }
}

// Setup link preview
document.getElementById("groupLink").addEventListener("input", function() {
    const url = this.value.trim();
    if (url.startsWith("http")) {
        fetchOpenGraph(url);
    } else {
        document.getElementById("preview").innerHTML = "";
    }
});
