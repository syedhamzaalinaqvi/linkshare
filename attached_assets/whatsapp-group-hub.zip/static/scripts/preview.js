
import { db } from './firebase-config.js';

// Preview WhatsApp group image when link is pasted
document.addEventListener('DOMContentLoaded', () => {
    const linkInput = document.getElementById('groupLink');
    if (linkInput) {
        linkInput.addEventListener('input', debounce(handleLinkPreview, 500));
        linkInput.addEventListener('paste', (e) => {
            setTimeout(() => handleLinkPreview(e), 100);
        });
    }
});

// Debounce function to limit API calls
function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

// Handle link preview
async function handleLinkPreview(event) {
    const linkInput = document.getElementById('groupLink');
    const previewDiv = document.getElementById('preview');
    const link = linkInput.value.trim();
    
    // Clear preview if no link
    if (!link) {
        previewDiv.innerHTML = '';
        return;
    }
    
    // Only process WhatsApp links
    if (!link.includes('whatsapp.com')) {
        previewDiv.innerHTML = `
            <div class="alert alert-warning mt-2" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Please enter a valid WhatsApp group link.
            </div>
        `;
        return;
    }
    
    // Show loading state
    previewDiv.innerHTML = `
        <div class="preview-box">
            <div class="d-flex align-items-center">
                <div class="spinner-border spinner-border-sm text-light me-2" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <span>Fetching group info...</span>
            </div>
        </div>
    `;
    
    try {
        // Extract group ID from link
        const groupId = extractGroupId(link);
        if (!groupId) {
            throw new Error("Invalid group link format");
        }
        
        // Fetch WhatsApp preview image (simulated for demo)
        // In a real app, you might use a backend API to fetch the actual preview
        const imageUrl = await fetchGroupImage(groupId);
        
        if (imageUrl) {
            console.log("Preview image URL:", imageUrl);
            previewDiv.innerHTML = `
                <div class="preview-box">
                    <div class="d-flex">
                        <img src="${imageUrl}" alt="Group preview" class="me-3">
                        <div>
                            <div class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Valid WhatsApp group link</div>
                            <small class="text-muted">Preview image successfully loaded</small>
                        </div>
                    </div>
                </div>
            `;
        } else {
            previewDiv.innerHTML = `
                <div class="preview-box">
                    <div class="d-flex align-items-center">
                        <div class="no-image-placeholder me-3" style="width: 100px; height: 100px;"></div>
                        <div>
                            <div class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Valid WhatsApp group link</div>
                            <small class="text-muted">No preview image available</small>
                        </div>
                    </div>
                </div>
            `;
        }
    } catch (error) {
        console.error("Preview error:", error);
        previewDiv.innerHTML = `
            <div class="preview-box">
                <div class="d-flex align-items-center">
                    <i class="fas fa-exclamation-circle text-warning me-2 fa-2x"></i>
                    <div>
                        <div>Unable to fetch group preview</div>
                        <small class="text-muted">Please make sure it's a valid WhatsApp group invite link</small>
                    </div>
                </div>
            </div>
        `;
    }
}

// Extract group ID from WhatsApp link
function extractGroupId(link) {
    try {
        // Attempt to extract group ID from link
        const url = new URL(link);
        if (url.hostname === 'chat.whatsapp.com') {
            return url.pathname.substring(1); // Remove leading slash
        }
        
        // Try to extract from the invite code format
        const match = link.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/);
        if (match && match[1]) {
            return match[1];
        }
        
        return null;
    } catch (e) {
        return null;
    }
}

// Simulate fetching group image (in a real app, you'd use a server-side API)
async function fetchGroupImage(groupId) {
    // This is a placeholder for demonstration
    // In a real application, you would fetch this from your server
    
    // For demo purposes, sometimes return a sample image
    if (Math.random() > 0.5) {
        return "https://pps.whatsapp.net/v/t61.24694-24/386451176_286293764215187_4239227016328392389_n.jpg?ccb=11-4&oh=01_Q5AaIINL36kbqEafGvVZQB1hzx5NVJfJs7lcBEnKiLmTroJ3&oe=67D96917&_nc_sid=5e03e0&_nc_cat=102";
    }
    
    // Log error message for debugging
    console.log("❌ No image found for:", groupId);
    return null;
}

async function fetchOpenGraph(url) {
    try {
        const response = await fetch(`https://api.allorigins.win/get?url=${encodeURIComponent(url)}`);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        const parser = new DOMParser();
        const doc = parser.parseFromString(data.contents, "text/html");

        // Extract OpenGraph metadata with better fallbacks
        const ogTitle = doc.querySelector('meta[property="og:title"]')?.content || 
                       doc.querySelector('meta[name="title"]')?.content ||
                       doc.title || "No Title Found";
                       
        const ogImage = doc.querySelector('meta[property="og:image"]')?.content || 
                       doc.querySelector('meta[name="image"]')?.content ||
                       doc.querySelector('link[rel="image_src"]')?.href ||
                       "https://via.placeholder.com/300x200?text=No+Preview+Available";
                       
        const ogDescription = doc.querySelector('meta[property="og:description"]')?.content || 
                             doc.querySelector('meta[name="description"]')?.content ||
                             "No Description Available";

        // Store the image URL in a data attribute for later use
        const previewHTML = `
            <div class="preview-box">
                <div class="d-flex gap-3">
                    <img src="${ogImage}" alt="Preview" class="preview-image" data-preview-url="${ogImage}">
                    <div>
                        <h5 class="mb-1">${ogTitle}</h5>
                        <p class="small text-muted mb-0">${ogDescription}</p>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById("preview").innerHTML = previewHTML;
        console.log("Preview image URL:", ogImage); // Debug log
    } catch (error) {
        console.error("Error fetching preview:", error);
        document.getElementById("preview").innerHTML = `
            <div class="alert alert-warning" role="alert">
                <i class="fas fa-exclamation-triangle"></i> 
                Could not load preview for this link
            </div>
        `;
    }
}

// Setup link preview
document.addEventListener('DOMContentLoaded', function() {
    const linkInput = document.getElementById("groupLink");
    if (linkInput) {
        linkInput.addEventListener("input", function() {
            const url = this.value.trim();
            const previewElement = document.getElementById("preview");
            
            if (url.startsWith("http") && previewElement) {
                fetchOpenGraph(url);
            } else if (previewElement) {
                previewElement.innerHTML = "";
            }
        });
    }
});
