import { collection, addDoc, getDocs, serverTimestamp, query, orderBy, limit, startAfter } from "https://www.gstatic.com/firebasejs/11.4.0/firebase-firestore.js";
import { db } from './firebase-config.js';

// Global variables for pagination and filtering
let lastVisibleGroup = null;
const groupsPerPage = 15;
let isLoading = false;
let allGroups = []; // Store all fetched groups
let displayedGroups = []; // Store filtered and sorted groups

// Render groups to the DOM
function renderGroups(groups) {
    const archiveDiv = document.getElementById("groupArchive");
    archiveDiv.innerHTML = "";

    if (groups.length === 0) {
        archiveDiv.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="no-results">
                    <i class="fas fa-search fa-3x mb-3"></i>
                    <h3>No groups found</h3>
                    <p>Try different search criteria or <button class="btn btn-link p-0" onclick="resetFilters()">reset filters</button></p>
                </div>
            </div>
        `;
        return;
    }

    groups.forEach((data) => {
        if (!data.title || !data.link) return;

        // Check for image in preview or use fallback
        const hasImage = data.image && data.image !== "undefined" && data.image !== "null";
        const imageHtml = hasImage 
            ? `<img src="${data.image}" alt="${data.title}" class="mb-3 group-image" onerror="this.src='https://via.placeholder.com/300x200?text=No+Preview+Available'">`
            : '<div class="no-image-placeholder mb-3">No Preview Available</div>';

        // Display category and country badges if available
        const categoryBadge = data.category ? 
            `<span class="badge bg-primary me-1">${data.category}</span>` : '';
        const countryBadge = data.country ? 
            `<span class="badge bg-secondary">${data.country}</span>` : '';

        const postHTML = `
            <div class="group-card">
                ${imageHtml}
                <h4>${data.title}</h4>
                <div class="mb-2">
                    ${categoryBadge}
                    ${countryBadge}
                </div>
                <p class="text-muted">${data.description || "No description"}</p>
                <div class="d-flex justify-content-between align-items-center">
                    <a href="${data.link}" target="_blank" class="btn btn-primary btn-sm">
                        <i class="fab fa-whatsapp"></i> Join Group
                    </a>
                    <small class="text-muted">
                        ${data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleDateString() : "N/A"}
                    </small>
                </div>
            </div>
        `;
        archiveDiv.innerHTML += postHTML;
    });
}

// Display groups with filtering
async function displayGroups(isLoadMore = false) {
    if (isLoading) return;
    isLoading = true;

    try {
        if (!isLoadMore) {
            // Initial load - fetch all groups
            const querySnapshot = await getDocs(collection(db, "groups"));
            allGroups = [];
            querySnapshot.forEach((doc) => {
                const data = doc.data();
                data.id = doc.id;
                allGroups.push(data);
            });

            // Sort by timestamp (newest first)
            allGroups.sort((a, b) => {
                if (!a.timestamp || !b.timestamp) return 0;
                return b.timestamp.seconds - a.timestamp.seconds;
            });

            // Apply filters and display
            applyFiltersAndDisplay();
        } else {
            // Load more - just display more from the already filtered list
            const currentCount = document.querySelectorAll('.group-card').length;
            const nextBatch = displayedGroups.slice(currentCount, currentCount + groupsPerPage);

            if (nextBatch.length > 0) {
                // Append to existing display
                const archiveDiv = document.getElementById("groupArchive");
                nextBatch.forEach((data) => {
                    if (!data.title || !data.link) return;

                    // Check for image in preview or use fallback
                    const hasImage = data.image && data.image !== "undefined" && data.image !== "null";
                    const imageHtml = hasImage 
                        ? `<img src="${data.image}" alt="${data.title}" class="mb-3 group-image" onerror="this.src='https://via.placeholder.com/300x200?text=No+Preview+Available'">`
                        : '<div class="no-image-placeholder mb-3">No Preview Available</div>';

                    // Display category and country badges if available
                    const categoryBadge = data.category ? 
                        `<span class="badge bg-primary me-1">${data.category}</span>` : '';
                    const countryBadge = data.country ? 
                        `<span class="badge bg-secondary">${data.country}</span>` : '';

                    const postHTML = `
                        <div class="group-card">
                            ${imageHtml}
                            <h4>${data.title}</h4>
                            <div class="mb-2">
                                ${categoryBadge}
                                ${countryBadge}
                            </div>
                            <p class="text-muted">${data.description || "No description"}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <a href="${data.link}" target="_blank" class="btn btn-primary btn-sm">
                                    <i class="fab fa-whatsapp"></i> Join Group
                                </a>
                                <small class="text-muted">
                                    ${data.timestamp ? new Date(data.timestamp.seconds * 1000).toLocaleDateString() : "N/A"}
                                </small>
                            </div>
                        </div>
                    `;
                    archiveDiv.innerHTML += postHTML;
                });
            }

            // Hide load more button if no more items to load
            const loadMoreBtn = document.getElementById("loadMoreBtn");
            if (loadMoreBtn && currentCount + nextBatch.length >= displayedGroups.length) {
                loadMoreBtn.style.display = "none";
            }
        }
    } catch (error) {
        console.error("Error loading groups:", error);
        showError("Failed to load groups. Please try again later.");
    } finally {
        isLoading = false;
    }
}

let activeFilters = {
    search: "",
    category: "",
    country: ""
};

function applyFiltersAndDisplay() {
    const filteredGroups = allGroups.filter(group => {
        const searchMatch = !activeFilters.search ||
            (group.title && group.title.toLowerCase().includes(activeFilters.search.toLowerCase())) ||
            (group.description && group.description.toLowerCase().includes(activeFilters.search.toLowerCase()));
        const categoryMatch = !activeFilters.category || (group.category && group.category === activeFilters.category);
        const countryMatch = !activeFilters.country || (group.country && group.country === activeFilters.country);
        return searchMatch && (categoryMatch || countryMatch || activeFilters.search); // Allow single filter
    });

    displayedGroups = filteredGroups; // Update displayedGroups after filtering

    renderGroups(filteredGroups.slice(0, groupsPerPage)); // Render first page
}

function resetFilters() {
    document.getElementById("searchInput").value = "";
    document.getElementById("categoryFilter").value = "";
    document.getElementById("countryFilter").value = "";
    activeFilters = { search: "", category: "", country: "" };
    applyFiltersAndDisplay();
}

function loadMoreGroups() {
    displayGroups(true);
}

function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function toggleScrollToTopButton() {
    const scrollToTopBtn = document.getElementById("scrollToTopBtn");
    if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        scrollToTopBtn.style.display = "block";
    } else {
        scrollToTopBtn.style.display = "none";
    }
}

function showSuccess(message) {
    const alertHTML = `
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    const alertContainer = document.getElementById("alertContainer");
    if (alertContainer) {
        alertContainer.innerHTML = alertHTML;
    }
}

function showError(message) {
    const alertHTML = `
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    const alertContainer = document.getElementById("alertContainer");
    if (alertContainer) {
        alertContainer.innerHTML = alertHTML;
    }
}

// Submit group
async function submitGroup() {
    // Disable submit button and show loading state
    const submitButton = document.getElementById("submitButton");
    const originalButtonText = '<i class="fas fa-plus-circle me-2"></i> Submit Group';
    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';

    // Set a timeout to reset the button after 6 seconds regardless of the result
    const buttonTimeout = setTimeout(() => {
        const btn = document.getElementById('submitButton');
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalButtonText;
        }
    }, 6000);

    try {
        // Get image URL from preview div if it exists
        const title = document.getElementById("groupTitle").value.trim();
        const link = document.getElementById("groupLink").value.trim();
        const category = document.getElementById("groupCategory").value.trim();
        const country = document.getElementById("groupCountry").value.trim();
        const description = document.getElementById("groupDescription").value.trim();

        // Get preview image from the preview container
        const previewImg = document.querySelector("#preview img");
        const imageUrl = previewImg ? previewImg.src : null;

        if (!title || !link || !category || !country || !description) {
            showError("Please fill all required fields");
            return;
        }

        if (!link.includes("chat.whatsapp.com")) {
            showError("Please enter a valid WhatsApp group link");
            return;
        }

        const groupData = {
            title,
            link,
            category,
            country,
            description,
            image: imageUrl, // Store the preview image URL
            timestamp: serverTimestamp()
        };

        console.log("Submitting group with image:", imageUrl); // Debug log

        await addDoc(collection(db, "groups"), groupData);
        showSuccess("Group added successfully!");
        clearForm();

        // Refresh groups display
        displayGroups();

        // If the operation finishes before the timeout, clear the timeout and reset button
        clearTimeout(buttonTimeout);
        const btn = document.getElementById('submitButton');
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalButtonText;
        }
    } catch (error) {
        console.error("Error adding document: ", error);
        showError("Failed to submit group. Please try again.");

        // If there's an error, clear the timeout and reset button
        clearTimeout(buttonTimeout);
        const btn = document.getElementById('submitButton');
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalButtonText;
        }
    }
}

//Clear form function
function clearForm() {
    document.getElementById("groupTitle").value = "";
    document.getElementById("groupLink").value = "";
    document.getElementById("groupCategory").value = "";
    document.getElementById("groupCountry").value = "";
    document.getElementById("groupDescription").value = "";
    document.getElementById("preview").innerHTML = "";
}

// Create group card function (This function is now obsolete because of renderGroups)
// function createGroupCard(groupData) { ... }


// Initialize 
window.onload = function() {
    displayGroups();

    // Initialize load more button
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', loadMoreGroups);
    }

    // Initialize scroll event listener
    window.addEventListener('scroll', toggleScrollToTopButton);
};

// Make functions accessible globally
window.submitGroup = submitGroup;
window.loadMoreGroups = loadMoreGroups;
window.scrollToTop = scrollToTop;
window.resetFilters = resetFilters;
window.clearForm = clearForm;

// Add event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add event listener for Search button
    const searchButton = document.getElementById("searchButton");
    if (searchButton) {
        searchButton.addEventListener("click", () => {
            activeFilters.search = document.getElementById("searchInput").value.trim();
            applyFiltersAndDisplay();
        });
    }

    // Add event listener for Search input (search on Enter key)
    const searchInput = document.getElementById("searchInput");
    if (searchInput) {
        searchInput.addEventListener("keyup", (event) => {
            if (event.key === "Enter") {
                activeFilters.search = searchInput.value.trim();
                applyFiltersAndDisplay();
            }
        });
    }

    // Add event listeners for Category and Country filters
    const categoryFilter = document.getElementById("categoryFilter");
    if (categoryFilter) {
        categoryFilter.addEventListener("change", () => {
            activeFilters.category = categoryFilter.value;
            applyFiltersAndDisplay();
        });
    }

    const countryFilter = document.getElementById("countryFilter");
    if (countryFilter) {
        countryFilter.addEventListener("change", () => {
            activeFilters.country = countryFilter.value;
            applyFiltersAndDisplay();
        });
    }
});